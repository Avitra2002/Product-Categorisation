# Product-Categorisation
VOCUS 2024 SDS Project &lt;Customer Feedback Product Categorisation and Sentiment Analysis with Gemini API>
